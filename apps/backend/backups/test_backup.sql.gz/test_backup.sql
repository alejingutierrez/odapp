--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

-- Started on 2025-08-14 16:40:06 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS oda_dev;
--
-- TOC entry 4494 (class 1262 OID 16384)
-- Name: oda_dev; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE oda_dev WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


\connect oda_dev

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 10 (class 2615 OID 17563)
-- Name: analytics; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA analytics;


--
-- TOC entry 11 (class 2615 OID 17564)
-- Name: audit; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA audit;


--
-- TOC entry 4 (class 3079 OID 16477)
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- TOC entry 4495 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- TOC entry 5 (class 3079 OID 16913)
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- TOC entry 4496 (class 0 OID 0)
-- Dependencies: 5
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 4497 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4498 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1235 (class 1247 OID 17640)
-- Name: AddressType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AddressType" AS ENUM (
    'BILLING',
    'SHIPPING',
    'BOTH'
);


--
-- TOC entry 1223 (class 1247 OID 17604)
-- Name: AdjustmentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AdjustmentType" AS ENUM (
    'INCREASE',
    'DECREASE',
    'SET'
);


--
-- TOC entry 1232 (class 1247 OID 17632)
-- Name: CustomerStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CustomerStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'BLOCKED'
);


--
-- TOC entry 1247 (class 1247 OID 17690)
-- Name: FinancialStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FinancialStatus" AS ENUM (
    'PENDING',
    'AUTHORIZED',
    'PARTIALLY_PAID',
    'PAID',
    'PARTIALLY_REFUNDED',
    'REFUNDED',
    'VOIDED'
);


--
-- TOC entry 1250 (class 1247 OID 17706)
-- Name: FulfillmentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FulfillmentStatus" AS ENUM (
    'UNFULFILLED',
    'PENDING',
    'SHIPPED',
    'DELIVERED',
    'CANCELLED'
);


--
-- TOC entry 1229 (class 1247 OID 17622)
-- Name: Gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Gender" AS ENUM (
    'MALE',
    'FEMALE',
    'OTHER',
    'PREFER_NOT_TO_SAY'
);


--
-- TOC entry 1274 (class 1247 OID 17806)
-- Name: HealthStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."HealthStatus" AS ENUM (
    'HEALTHY',
    'DEGRADED',
    'UNHEALTHY'
);


--
-- TOC entry 1238 (class 1247 OID 17648)
-- Name: InteractionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InteractionType" AS ENUM (
    'EMAIL',
    'PHONE',
    'CHAT',
    'MEETING',
    'NOTE',
    'COMPLAINT',
    'COMPLIMENT'
);


--
-- TOC entry 1220 (class 1247 OID 17594)
-- Name: LocationType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LocationType" AS ENUM (
    'WAREHOUSE',
    'STORE',
    'SUPPLIER',
    'CUSTOMER'
);


--
-- TOC entry 1241 (class 1247 OID 17664)
-- Name: LoyaltyTransactionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LoyaltyTransactionType" AS ENUM (
    'EARNED',
    'REDEEMED',
    'EXPIRED',
    'ADJUSTED'
);


--
-- TOC entry 1244 (class 1247 OID 17674)
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'CONFIRMED',
    'PROCESSING',
    'SHIPPED',
    'DELIVERED',
    'CANCELLED',
    'REFUNDED'
);


--
-- TOC entry 1256 (class 1247 OID 17732)
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CREDIT_CARD',
    'DEBIT_CARD',
    'PAYPAL',
    'BANK_TRANSFER',
    'CASH',
    'STORE_CREDIT',
    'OTHER'
);


--
-- TOC entry 1253 (class 1247 OID 17718)
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'CANCELLED',
    'REFUNDED'
);


--
-- TOC entry 1217 (class 1247 OID 17586)
-- Name: ProductStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductStatus" AS ENUM (
    'DRAFT',
    'ACTIVE',
    'ARCHIVED'
);


--
-- TOC entry 1262 (class 1247 OID 17762)
-- Name: ReturnCondition; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReturnCondition" AS ENUM (
    'UNOPENED',
    'OPENED',
    'USED',
    'DAMAGED',
    'DEFECTIVE'
);


--
-- TOC entry 1259 (class 1247 OID 17748)
-- Name: ReturnStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReturnStatus" AS ENUM (
    'REQUESTED',
    'APPROVED',
    'REJECTED',
    'RECEIVED',
    'PROCESSED',
    'REFUNDED'
);


--
-- TOC entry 1271 (class 1247 OID 17798)
-- Name: SyncDirection; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SyncDirection" AS ENUM (
    'TO_SHOPIFY',
    'FROM_SHOPIFY',
    'BIDIRECTIONAL'
);


--
-- TOC entry 1268 (class 1247 OID 17786)
-- Name: SyncStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SyncStatus" AS ENUM (
    'PENDING',
    'RUNNING',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


--
-- TOC entry 1265 (class 1247 OID 17774)
-- Name: SyncType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SyncType" AS ENUM (
    'PRODUCTS',
    'INVENTORY',
    'ORDERS',
    'CUSTOMERS',
    'COLLECTIONS'
);


--
-- TOC entry 1226 (class 1247 OID 17612)
-- Name: TransferStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TransferStatus" AS ENUM (
    'PENDING',
    'SHIPPED',
    'RECEIVED',
    'CANCELLED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 220 (class 1259 OID 17574)
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 253 (class 1259 OID 18123)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    action text NOT NULL,
    entity text NOT NULL,
    "entityId" text NOT NULL,
    "oldValues" jsonb,
    "newValues" jsonb,
    "userId" text,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 17848)
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    image text,
    "parentId" text,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "metaTitle" text,
    "metaDescription" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 17905)
-- Name: collection_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collection_products (
    id text NOT NULL,
    "collectionId" text NOT NULL,
    "productId" text NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 17858)
-- Name: collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    image text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    rules jsonb,
    "metaTitle" text,
    "metaDescription" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 17988)
-- Name: customer_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_addresses (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "firstName" text,
    "lastName" text,
    company text,
    address1 text NOT NULL,
    address2 text,
    city text NOT NULL,
    state text,
    country text NOT NULL,
    "postalCode" text,
    phone text,
    "isDefault" boolean DEFAULT false NOT NULL,
    type public."AddressType" DEFAULT 'SHIPPING'::public."AddressType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 18015)
-- Name: customer_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_interactions (
    id text NOT NULL,
    "customerId" text NOT NULL,
    type public."InteractionType" NOT NULL,
    channel text NOT NULL,
    subject text,
    content text,
    outcome text,
    metadata jsonb,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 241 (class 1259 OID 18007)
-- Name: customer_segment_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_segment_members (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "segmentId" text NOT NULL,
    "addedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 240 (class 1259 OID 17998)
-- Name: customer_segments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_segments (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    rules jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 238 (class 1259 OID 17970)
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id text NOT NULL,
    email text,
    phone text,
    "firstName" text,
    "lastName" text,
    "dateOfBirth" timestamp(3) without time zone,
    gender public."Gender",
    language text,
    currency text,
    "marketingOptIn" boolean DEFAULT false NOT NULL,
    "emailOptIn" boolean DEFAULT false NOT NULL,
    "smsOptIn" boolean DEFAULT false NOT NULL,
    status public."CustomerStatus" DEFAULT 'ACTIVE'::public."CustomerStatus" NOT NULL,
    "customerSince" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastOrderAt" timestamp(3) without time zone,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL,
    "loyaltyTier" text,
    "lifetimeValue" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalSpent" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalOrders" integer DEFAULT 0 NOT NULL,
    "averageOrderValue" numeric(10,2) DEFAULT 0 NOT NULL,
    "shopifyId" text,
    "lastSyncedAt" timestamp(3) without time zone,
    tags text[],
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


--
-- TOC entry 248 (class 1259 OID 18073)
-- Name: fulfillment_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillment_items (
    id text NOT NULL,
    "fulfillmentId" text NOT NULL,
    "orderItemId" text NOT NULL,
    quantity integer NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 18064)
-- Name: fulfillments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillments (
    id text NOT NULL,
    "orderId" text NOT NULL,
    status public."FulfillmentStatus" DEFAULT 'PENDING'::public."FulfillmentStatus" NOT NULL,
    "trackingNumber" text,
    "trackingUrl" text,
    carrier text,
    service text,
    "shippedAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 17936)
-- Name: inventory_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_adjustments (
    id text NOT NULL,
    "inventoryItemId" text NOT NULL,
    type public."AdjustmentType" NOT NULL,
    "quantityChange" integer NOT NULL,
    reason text,
    notes text,
    "unitCost" numeric(10,4),
    "totalCostImpact" numeric(10,2),
    "referenceType" text,
    "referenceId" text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 17924)
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_items (
    id text NOT NULL,
    "productId" text,
    "variantId" text,
    "locationId" text NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    "reservedQuantity" integer DEFAULT 0 NOT NULL,
    "availableQuantity" integer DEFAULT 0 NOT NULL,
    "lowStockThreshold" integer DEFAULT 0 NOT NULL,
    "averageCost" numeric(10,4),
    "lastCost" numeric(10,4),
    "shopifyInventoryItemId" text,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 235 (class 1259 OID 17944)
-- Name: inventory_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_reservations (
    id text NOT NULL,
    "inventoryItemId" text NOT NULL,
    quantity integer NOT NULL,
    reason text NOT NULL,
    "referenceId" text,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 17961)
-- Name: inventory_transfer_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_transfer_items (
    id text NOT NULL,
    "transferId" text NOT NULL,
    "productId" text,
    "variantId" text,
    "quantityRequested" integer NOT NULL,
    "quantityShipped" integer DEFAULT 0 NOT NULL,
    "quantityReceived" integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 17952)
-- Name: inventory_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_transfers (
    id text NOT NULL,
    "fromLocationId" text NOT NULL,
    "toLocationId" text NOT NULL,
    status public."TransferStatus" DEFAULT 'PENDING'::public."TransferStatus" NOT NULL,
    notes text,
    "trackingNumber" text,
    "shippedAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 232 (class 1259 OID 17914)
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    type public."LocationType" NOT NULL,
    address text,
    city text,
    state text,
    country text,
    "postalCode" text,
    phone text,
    email text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 18023)
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loyalty_transactions (
    id text NOT NULL,
    "customerId" text NOT NULL,
    type public."LoyaltyTransactionType" NOT NULL,
    points integer NOT NULL,
    description text,
    "referenceType" text,
    "referenceId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 245 (class 1259 OID 18045)
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text,
    "variantId" text,
    name text NOT NULL,
    sku text,
    quantity integer NOT NULL,
    price numeric(10,2) NOT NULL,
    "totalPrice" numeric(10,2) NOT NULL,
    "quantityFulfilled" integer DEFAULT 0 NOT NULL,
    "quantityReturned" integer DEFAULT 0 NOT NULL,
    "productSnapshot" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 18031)
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    "customerId" text,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    "financialStatus" public."FinancialStatus" DEFAULT 'PENDING'::public."FinancialStatus" NOT NULL,
    "fulfillmentStatus" public."FulfillmentStatus" DEFAULT 'UNFULFILLED'::public."FulfillmentStatus" NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "taxAmount" numeric(10,2) NOT NULL,
    "shippingAmount" numeric(10,2) NOT NULL,
    "discountAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "billingAddressId" text,
    "shippingAddressId" text,
    "shippingMethod" text,
    "trackingNumber" text,
    "trackingUrl" text,
    "orderDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "shippedAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "cancelledAt" timestamp(3) without time zone,
    "guestEmail" text,
    "guestPhone" text,
    "shopifyId" text,
    "shopifyOrderNumber" text,
    "lastSyncedAt" timestamp(3) without time zone,
    notes text,
    tags text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 18055)
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id text NOT NULL,
    "orderId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    method public."PaymentMethod" NOT NULL,
    gateway text NOT NULL,
    "gatewayTransactionId" text,
    metadata jsonb,
    "processedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 230 (class 1259 OID 17898)
-- Name: product_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_attributes (
    id text NOT NULL,
    "productId" text NOT NULL,
    name text NOT NULL,
    value text NOT NULL
);


--
-- TOC entry 229 (class 1259 OID 17889)
-- Name: product_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_images (
    id text NOT NULL,
    "productId" text NOT NULL,
    url text NOT NULL,
    "altText" text,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    width integer,
    height integer,
    "fileSize" integer,
    "mimeType" text,
    "shopifyId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 17880)
-- Name: product_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variants (
    id text NOT NULL,
    "productId" text NOT NULL,
    name text,
    sku text,
    barcode text,
    "option1Name" text,
    "option1Value" text,
    "option2Name" text,
    "option2Value" text,
    "option3Name" text,
    "option3Value" text,
    price numeric(10,2) NOT NULL,
    "compareAtPrice" numeric(10,2),
    "costPrice" numeric(10,2),
    weight numeric(8,3),
    dimensions jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "shopifyId" text,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 17868)
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    "shortDescription" text,
    sku text,
    barcode text,
    brand text,
    material text,
    "careInstructions" text,
    price numeric(10,2) NOT NULL,
    "compareAtPrice" numeric(10,2),
    "costPrice" numeric(10,2),
    status public."ProductStatus" DEFAULT 'DRAFT'::public."ProductStatus" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isFeatured" boolean DEFAULT false NOT NULL,
    "trackQuantity" boolean DEFAULT true NOT NULL,
    "metaTitle" text,
    "metaDescription" text,
    "shopifyId" text,
    "shopifyHandle" text,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "categoryId" text
);


--
-- TOC entry 250 (class 1259 OID 18090)
-- Name: return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_items (
    id text NOT NULL,
    "returnId" text NOT NULL,
    "orderItemId" text NOT NULL,
    quantity integer NOT NULL,
    reason text,
    condition public."ReturnCondition" DEFAULT 'UNOPENED'::public."ReturnCondition" NOT NULL
);


--
-- TOC entry 249 (class 1259 OID 18080)
-- Name: returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.returns (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "returnNumber" text NOT NULL,
    status public."ReturnStatus" DEFAULT 'REQUESTED'::public."ReturnStatus" NOT NULL,
    reason text,
    notes text,
    "refundAmount" numeric(10,2),
    "refundedAt" timestamp(3) without time zone,
    "requestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "processedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 17824)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    permissions jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 251 (class 1259 OID 18098)
-- Name: shopify_syncs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopify_syncs (
    id text NOT NULL,
    type public."SyncType" NOT NULL,
    status public."SyncStatus" DEFAULT 'PENDING'::public."SyncStatus" NOT NULL,
    direction public."SyncDirection" NOT NULL,
    "totalItems" integer DEFAULT 0 NOT NULL,
    "processedItems" integer DEFAULT 0 NOT NULL,
    "successItems" integer DEFAULT 0 NOT NULL,
    "errorItems" integer DEFAULT 0 NOT NULL,
    errors jsonb,
    "lastError" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 3 NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "nextRetryAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 252 (class 1259 OID 18113)
-- Name: shopify_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopify_webhooks (
    id text NOT NULL,
    topic text NOT NULL,
    "shopDomain" text NOT NULL,
    payload jsonb NOT NULL,
    headers jsonb,
    processed boolean DEFAULT false NOT NULL,
    "processedAt" timestamp(3) without time zone,
    error text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 254 (class 1259 OID 18131)
-- Name: system_health; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_health (
    id text NOT NULL,
    service text NOT NULL,
    status public."HealthStatus" NOT NULL,
    message text,
    metadata jsonb,
    "checkedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 17832)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id text NOT NULL,
    "userId" text NOT NULL,
    "roleId" text NOT NULL,
    "assignedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "assignedBy" text
);


--
-- TOC entry 224 (class 1259 OID 17840)
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "refreshToken" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastUsedAt" timestamp(3) without time zone,
    "ipAddress" text,
    "userAgent" text
);


--
-- TOC entry 221 (class 1259 OID 17813)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    username text,
    "firstName" text,
    "lastName" text,
    avatar text,
    phone text,
    "passwordHash" text NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text,
    "lastLoginAt" timestamp(3) without time zone,
    "loginAttempts" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


--
-- TOC entry 4454 (class 0 OID 17574)
-- Dependencies: 220
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
318c1984-01fb-44ec-84d4-9321156b5149	7b9b41cf26537cae4fd5bae174cedd61a62cd75a1bf9b40531fd4063aedf7037	2025-08-14 15:55:08.747684+00	20250814155502_init	\N	\N	2025-08-14 15:55:04.091197+00	1
9d076666-1102-4729-87ee-40ad997e4b56	8cf513e4a2e45bfe71fbf5a9b8a8fdd83afd667ddefbf2c72eadbdbda063bb5e	\N	20250814155503_add_performance_indexes	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250814155503_add_performance_indexes\n\nDatabase error code: 25001\n\nDatabase error:\nERROR: CREATE INDEX CONCURRENTLY cannot run inside a transaction block\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E25001), message: "CREATE INDEX CONCURRENTLY cannot run inside a transaction block", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("xact.c"), line: Some(3476), routine: Some("PreventInTransactionBlock") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250814155503_add_performance_indexes"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20250814155503_add_performance_indexes"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2025-08-14 16:08:00.867767+00	2025-08-14 16:05:48.771741+00	0
e883cd00-b627-4114-a33c-a633cf2d00ef	a0872ea7ad2c2d30f4aa048749a3ee506e84dda8d851acd1a9364b98a75ae05c	2025-08-14 16:08:00.87714+00	20250814155503_add_performance_indexes		\N	2025-08-14 16:08:00.87714+00	0
\.


--
-- TOC entry 4487 (class 0 OID 18123)
-- Dependencies: 253
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, action, entity, "entityId", "oldValues", "newValues", "userId", "ipAddress", "userAgent", "createdAt") FROM stdin;
\.


--
-- TOC entry 4459 (class 0 OID 17848)
-- Dependencies: 225
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, slug, description, image, "parentId", "sortOrder", "isActive", "metaTitle", "metaDescription", "createdAt", "updatedAt") FROM stdin;
cmebl42ki0008cjvuud4642ks	Women	women	Women's fashion and accessories	\N	\N	1	t	\N	\N	2025-08-14 15:59:12.642	2025-08-14 15:59:12.642
cmebl42l60009cjvuf2999tz8	Men	men	Men's fashion and accessories	\N	\N	2	t	\N	\N	2025-08-14 15:59:12.667	2025-08-14 15:59:12.667
cmebl42lg000bcjvuxqrzjs3b	Tops	women-tops	Women's tops, blouses, and shirts	\N	cmebl42ki0008cjvuud4642ks	1	t	\N	\N	2025-08-14 15:59:12.676	2025-08-14 15:59:12.676
cmebl42ln000dcjvuke0lk6av	Bottoms	women-bottoms	Women's pants, skirts, and shorts	\N	cmebl42ki0008cjvuud4642ks	2	t	\N	\N	2025-08-14 15:59:12.683	2025-08-14 15:59:12.683
cmebl42lr000fcjvux84wl345	Tops	men-tops	Men's shirts, t-shirts, and sweaters	\N	cmebl42l60009cjvuf2999tz8	1	t	\N	\N	2025-08-14 15:59:12.687	2025-08-14 15:59:12.687
\.


--
-- TOC entry 4465 (class 0 OID 17905)
-- Dependencies: 231
-- Data for Name: collection_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collection_products (id, "collectionId", "productId", "sortOrder", "createdAt") FROM stdin;
cmebl42pa0015cjvukdx1iqy4	cmebl42lx000gcjvup0xv1mn1	cmebl42mb000jcjvu3b11ailx	1	2025-08-14 15:59:12.814
\.


--
-- TOC entry 4460 (class 0 OID 17858)
-- Dependencies: 226
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections (id, name, slug, description, image, "isActive", "sortOrder", rules, "metaTitle", "metaDescription", "createdAt", "updatedAt") FROM stdin;
cmebl42lx000gcjvup0xv1mn1	Spring 2024	spring-2024	Fresh styles for the spring season	\N	t	1	\N	\N	\N	2025-08-14 15:59:12.694	2025-08-14 15:59:12.694
cmebl42m6000hcjvueewryb29	Summer 2024	summer-2024	Light and breezy summer fashion	\N	t	2	\N	\N	\N	2025-08-14 15:59:12.703	2025-08-14 15:59:12.703
\.


--
-- TOC entry 4473 (class 0 OID 17988)
-- Dependencies: 239
-- Data for Name: customer_addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_addresses (id, "customerId", "firstName", "lastName", company, address1, address2, city, state, country, "postalCode", phone, "isDefault", type, "createdAt", "updatedAt") FROM stdin;
cmebl42q60018cjvudkk1ompk	cmebl42pj0016cjvulzzcl0tv	Jane	Doe	\N	789 Customer Lane	\N	Customer City	CC	US	12347	+1-555-0199	t	BOTH	2025-08-14 15:59:12.846	2025-08-14 15:59:12.846
\.


--
-- TOC entry 4476 (class 0 OID 18015)
-- Dependencies: 242
-- Data for Name: customer_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_interactions (id, "customerId", type, channel, subject, content, outcome, metadata, "createdBy", "createdAt") FROM stdin;
\.


--
-- TOC entry 4475 (class 0 OID 18007)
-- Dependencies: 241
-- Data for Name: customer_segment_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_segment_members (id, "customerId", "segmentId", "addedAt") FROM stdin;
\.


--
-- TOC entry 4474 (class 0 OID 17998)
-- Dependencies: 240
-- Data for Name: customer_segments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_segments (id, name, description, rules, "isActive", "createdAt", "updatedAt") FROM stdin;
cmebl42qq0019cjvucqenw0a9	VIP Customers	High-value customers with lifetime value > $500	{"conditions": [{"field": "lifetimeValue", "value": 500, "operator": "gte"}]}	t	2025-08-14 15:59:12.866	2025-08-14 15:59:12.866
cmebl42rf001acjvu6dsdb21y	Frequent Buyers	Customers with 5+ orders	{"conditions": [{"field": "totalOrders", "value": 5, "operator": "gte"}]}	t	2025-08-14 15:59:12.891	2025-08-14 15:59:12.891
\.


--
-- TOC entry 4472 (class 0 OID 17970)
-- Dependencies: 238
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, email, phone, "firstName", "lastName", "dateOfBirth", gender, language, currency, "marketingOptIn", "emailOptIn", "smsOptIn", status, "customerSince", "lastOrderAt", "loyaltyPoints", "loyaltyTier", "lifetimeValue", "totalSpent", "totalOrders", "averageOrderValue", "shopifyId", "lastSyncedAt", tags, notes, "createdAt", "updatedAt", "deletedAt") FROM stdin;
cmebl42pj0016cjvulzzcl0tv	jane.doe@example.com	+1-555-0199	Jane	Doe	1990-05-15 00:00:00	FEMALE	en	USD	t	t	f	ACTIVE	2025-08-14 15:59:12.824	\N	100	\N	150.00	150.00	2	75.00	\N	\N	{vip,frequent-buyer}	\N	2025-08-14 15:59:12.824	2025-08-14 15:59:12.824	\N
\.


--
-- TOC entry 4482 (class 0 OID 18073)
-- Dependencies: 248
-- Data for Name: fulfillment_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillment_items (id, "fulfillmentId", "orderItemId", quantity) FROM stdin;
\.


--
-- TOC entry 4481 (class 0 OID 18064)
-- Dependencies: 247
-- Data for Name: fulfillments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillments (id, "orderId", status, "trackingNumber", "trackingUrl", carrier, service, "shippedAt", "deliveredAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4468 (class 0 OID 17936)
-- Dependencies: 234
-- Data for Name: inventory_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_adjustments (id, "inventoryItemId", type, "quantityChange", reason, notes, "unitCost", "totalCostImpact", "referenceType", "referenceId", "createdBy", "createdAt") FROM stdin;
\.


--
-- TOC entry 4467 (class 0 OID 17924)
-- Dependencies: 233
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_items (id, "productId", "variantId", "locationId", quantity, "reservedQuantity", "availableQuantity", "lowStockThreshold", "averageCost", "lastCost", "shopifyInventoryItemId", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
cmebl42ne000ncjvuh2ufydsk	cmebl42mb000jcjvu3b11ailx	cmebl42n2000lcjvuowgsz1fx	cmebl42ji0006cjvuo4o9lp5i	100	0	100	10	15.0000	15.0000	\N	\N	2025-08-14 15:59:12.746	2025-08-14 15:59:12.746
cmebl42nz000rcjvue9anrzwk	cmebl42mb000jcjvu3b11ailx	cmebl42nr000pcjvukiyf23kw	cmebl42ji0006cjvuo4o9lp5i	100	0	100	10	15.0000	15.0000	\N	\N	2025-08-14 15:59:12.767	2025-08-14 15:59:12.767
cmebl42ob000vcjvu0y8nnoob	cmebl42mb000jcjvu3b11ailx	cmebl42o5000tcjvuig0us9ds	cmebl42ji0006cjvuo4o9lp5i	100	0	100	10	15.0000	15.0000	\N	\N	2025-08-14 15:59:12.779	2025-08-14 15:59:12.779
cmebl42om000zcjvu9eeb8opr	cmebl42mb000jcjvu3b11ailx	cmebl42og000xcjvum7bv60we	cmebl42ji0006cjvuo4o9lp5i	100	0	100	10	15.0000	15.0000	\N	\N	2025-08-14 15:59:12.79	2025-08-14 15:59:12.79
cmebl42p30013cjvuszwxphtx	cmebl42mb000jcjvu3b11ailx	cmebl42ow0011cjvun16okbri	cmebl42ji0006cjvuo4o9lp5i	100	0	100	10	15.0000	15.0000	\N	\N	2025-08-14 15:59:12.807	2025-08-14 15:59:12.807
\.


--
-- TOC entry 4469 (class 0 OID 17944)
-- Dependencies: 235
-- Data for Name: inventory_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_reservations (id, "inventoryItemId", quantity, reason, "referenceId", "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4471 (class 0 OID 17961)
-- Dependencies: 237
-- Data for Name: inventory_transfer_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_transfer_items (id, "transferId", "productId", "variantId", "quantityRequested", "quantityShipped", "quantityReceived") FROM stdin;
\.


--
-- TOC entry 4470 (class 0 OID 17952)
-- Dependencies: 236
-- Data for Name: inventory_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_transfers (id, "fromLocationId", "toLocationId", status, notes, "trackingNumber", "shippedAt", "receivedAt", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4466 (class 0 OID 17914)
-- Dependencies: 232
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.locations (id, name, code, type, address, city, state, country, "postalCode", phone, email, "isActive", "isDefault", "createdAt", "updatedAt") FROM stdin;
cmebl42ji0006cjvuo4o9lp5i	Main Warehouse	MAIN-WH	WAREHOUSE	123 Warehouse Street	Fashion City	FC	US	12345	+1-555-0123	warehouse@oda.local	t	t	2025-08-14 15:59:12.606	2025-08-14 15:59:12.606
cmebl42k80007cjvuv80ken74	Flagship Store	STORE-01	STORE	456 Fashion Avenue	Fashion City	FC	US	12346	+1-555-0124	store@oda.local	t	f	2025-08-14 15:59:12.632	2025-08-14 15:59:12.632
\.


--
-- TOC entry 4477 (class 0 OID 18023)
-- Dependencies: 243
-- Data for Name: loyalty_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loyalty_transactions (id, "customerId", type, points, description, "referenceType", "referenceId", "createdAt") FROM stdin;
\.


--
-- TOC entry 4479 (class 0 OID 18045)
-- Dependencies: 245
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, "orderId", "productId", "variantId", name, sku, quantity, price, "totalPrice", "quantityFulfilled", "quantityReturned", "productSnapshot", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4478 (class 0 OID 18031)
-- Dependencies: 244
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, "orderNumber", "customerId", status, "financialStatus", "fulfillmentStatus", subtotal, "taxAmount", "shippingAmount", "discountAmount", "totalAmount", currency, "billingAddressId", "shippingAddressId", "shippingMethod", "trackingNumber", "trackingUrl", "orderDate", "shippedAt", "deliveredAt", "cancelledAt", "guestEmail", "guestPhone", "shopifyId", "shopifyOrderNumber", "lastSyncedAt", notes, tags, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4480 (class 0 OID 18055)
-- Dependencies: 246
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, "orderId", amount, currency, status, method, gateway, "gatewayTransactionId", metadata, "processedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4464 (class 0 OID 17898)
-- Dependencies: 230
-- Data for Name: product_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_attributes (id, "productId", name, value) FROM stdin;
\.


--
-- TOC entry 4463 (class 0 OID 17889)
-- Dependencies: 229
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_images (id, "productId", url, "altText", "sortOrder", width, height, "fileSize", "mimeType", "shopifyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4462 (class 0 OID 17880)
-- Dependencies: 228
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variants (id, "productId", name, sku, barcode, "option1Name", "option1Value", "option2Name", "option2Value", "option3Name", "option3Value", price, "compareAtPrice", "costPrice", weight, dimensions, "isActive", "shopifyId", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
cmebl42n2000lcjvuowgsz1fx	cmebl42mb000jcjvu3b11ailx	XS - White	CWT-001-XS-WHT	\N	Size	XS	Color	White	\N	\N	29.99	\N	15.00	0.200	\N	t	\N	\N	2025-08-14 15:59:12.735	2025-08-14 15:59:12.735
cmebl42nr000pcjvukiyf23kw	cmebl42mb000jcjvu3b11ailx	S - White	CWT-001-S-WHT	\N	Size	S	Color	White	\N	\N	29.99	\N	15.00	0.200	\N	t	\N	\N	2025-08-14 15:59:12.76	2025-08-14 15:59:12.76
cmebl42o5000tcjvuig0us9ds	cmebl42mb000jcjvu3b11ailx	M - White	CWT-001-M-WHT	\N	Size	M	Color	White	\N	\N	29.99	\N	15.00	0.200	\N	t	\N	\N	2025-08-14 15:59:12.773	2025-08-14 15:59:12.773
cmebl42og000xcjvum7bv60we	cmebl42mb000jcjvu3b11ailx	L - White	CWT-001-L-WHT	\N	Size	L	Color	White	\N	\N	29.99	\N	15.00	0.200	\N	t	\N	\N	2025-08-14 15:59:12.784	2025-08-14 15:59:12.784
cmebl42ow0011cjvun16okbri	cmebl42mb000jcjvu3b11ailx	XL - White	CWT-001-XL-WHT	\N	Size	XL	Color	White	\N	\N	29.99	\N	15.00	0.200	\N	t	\N	\N	2025-08-14 15:59:12.801	2025-08-14 15:59:12.801
\.


--
-- TOC entry 4461 (class 0 OID 17868)
-- Dependencies: 227
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, slug, description, "shortDescription", sku, barcode, brand, material, "careInstructions", price, "compareAtPrice", "costPrice", status, "isActive", "isFeatured", "trackQuantity", "metaTitle", "metaDescription", "shopifyId", "shopifyHandle", "lastSyncedAt", "createdAt", "updatedAt", "deletedAt", "categoryId") FROM stdin;
cmebl42mb000jcjvu3b11ailx	Classic White T-Shirt	classic-white-tee	A timeless classic white t-shirt made from 100% organic cotton	Classic white t-shirt in organic cotton	CWT-001	\N	Oda Basics	100% Organic Cotton	Machine wash cold, tumble dry low	29.99	39.99	15.00	ACTIVE	t	t	t	\N	\N	\N	\N	\N	2025-08-14 15:59:12.707	2025-08-14 15:59:12.707	\N	cmebl42lg000bcjvuxqrzjs3b
\.


--
-- TOC entry 4484 (class 0 OID 18090)
-- Dependencies: 250
-- Data for Name: return_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_items (id, "returnId", "orderItemId", quantity, reason, condition) FROM stdin;
\.


--
-- TOC entry 4483 (class 0 OID 18080)
-- Dependencies: 249
-- Data for Name: returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.returns (id, "orderId", "returnNumber", status, reason, notes, "refundAmount", "refundedAt", "requestedAt", "approvedAt", "receivedAt", "processedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4456 (class 0 OID 17824)
-- Dependencies: 222
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, permissions, "createdAt", "updatedAt") FROM stdin;
cmebl424t0000cjvupausqraa	admin	Full system administrator access	["users:read", "users:write", "users:delete", "products:read", "products:write", "products:delete", "inventory:read", "inventory:write", "orders:read", "orders:write", "customers:read", "customers:write", "analytics:read", "settings:read", "settings:write", "shopify:read", "shopify:write"]	2025-08-14 15:59:12.077	2025-08-14 15:59:12.077
cmebl42600001cjvugq13v4o5	manager	Store manager with limited admin access	["products:read", "products:write", "inventory:read", "inventory:write", "orders:read", "orders:write", "customers:read", "customers:write", "analytics:read"]	2025-08-14 15:59:12.12	2025-08-14 15:59:12.12
cmebl42680002cjvusts26i79	employee	Basic employee access	["products:read", "inventory:read", "orders:read", "orders:write", "customers:read", "customers:write"]	2025-08-14 15:59:12.128	2025-08-14 15:59:12.128
\.


--
-- TOC entry 4485 (class 0 OID 18098)
-- Dependencies: 251
-- Data for Name: shopify_syncs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shopify_syncs (id, type, status, direction, "totalItems", "processedItems", "successItems", "errorItems", errors, "lastError", "retryCount", "maxRetries", "startedAt", "completedAt", "nextRetryAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4486 (class 0 OID 18113)
-- Dependencies: 252
-- Data for Name: shopify_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shopify_webhooks (id, topic, "shopDomain", payload, headers, processed, "processedAt", error, "retryCount", "receivedAt") FROM stdin;
\.


--
-- TOC entry 4488 (class 0 OID 18131)
-- Dependencies: 254
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_health (id, service, status, message, metadata, "checkedAt") FROM stdin;
\.


--
-- TOC entry 4457 (class 0 OID 17832)
-- Dependencies: 223
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, "userId", "roleId", "assignedAt", "assignedBy") FROM stdin;
cmebl42j80005cjvul26k9dv9	cmebl42iq0003cjvu7e32vn6z	cmebl424t0000cjvupausqraa	2025-08-14 15:59:12.596	\N
\.


--
-- TOC entry 4458 (class 0 OID 17840)
-- Dependencies: 224
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, "userId", token, "refreshToken", "expiresAt", "createdAt", "lastUsedAt", "ipAddress", "userAgent") FROM stdin;
\.


--
-- TOC entry 4455 (class 0 OID 17813)
-- Dependencies: 221
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, username, "firstName", "lastName", avatar, phone, "passwordHash", "emailVerified", "emailVerifiedAt", "twoFactorEnabled", "twoFactorSecret", "lastLoginAt", "loginAttempts", "lockedUntil", "createdAt", "updatedAt", "deletedAt") FROM stdin;
cmebl42iq0003cjvu7e32vn6z	admin@oda.local	admin	System	Administrator	\N	\N	$2a$12$BDIWv0F.caByFjyl83PAFOccDIOzvddxZqTveSj0ghchHCHHaihji	t	2025-08-14 15:59:12.576	f	\N	\N	0	\N	2025-08-14 15:59:12.578	2025-08-14 15:59:12.578	\N
\.


--
-- TOC entry 4025 (class 2606 OID 17582)
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4263 (class 2606 OID 18130)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4051 (class 2606 OID 17857)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- TOC entry 4107 (class 2606 OID 17913)
-- Name: collection_products collection_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_products
    ADD CONSTRAINT collection_products_pkey PRIMARY KEY (id);


--
-- TOC entry 4058 (class 2606 OID 17867)
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (id);


--
-- TOC entry 4170 (class 2606 OID 17997)
-- Name: customer_addresses customer_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_addresses
    ADD CONSTRAINT customer_addresses_pkey PRIMARY KEY (id);


--
-- TOC entry 4184 (class 2606 OID 18022)
-- Name: customer_interactions customer_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_interactions
    ADD CONSTRAINT customer_interactions_pkey PRIMARY KEY (id);


--
-- TOC entry 4180 (class 2606 OID 18014)
-- Name: customer_segment_members customer_segment_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_segment_members
    ADD CONSTRAINT customer_segment_members_pkey PRIMARY KEY (id);


--
-- TOC entry 4177 (class 2606 OID 18006)
-- Name: customer_segments customer_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_segments
    ADD CONSTRAINT customer_segments_pkey PRIMARY KEY (id);


--
-- TOC entry 4154 (class 2606 OID 17987)
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- TOC entry 4235 (class 2606 OID 18079)
-- Name: fulfillment_items fulfillment_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_items
    ADD CONSTRAINT fulfillment_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4230 (class 2606 OID 18072)
-- Name: fulfillments fulfillments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillments
    ADD CONSTRAINT fulfillments_pkey PRIMARY KEY (id);


--
-- TOC entry 4133 (class 2606 OID 17943)
-- Name: inventory_adjustments inventory_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_pkey PRIMARY KEY (id);


--
-- TOC entry 4124 (class 2606 OID 17935)
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4138 (class 2606 OID 17951)
-- Name: inventory_reservations inventory_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_pkey PRIMARY KEY (id);


--
-- TOC entry 4146 (class 2606 OID 17969)
-- Name: inventory_transfer_items inventory_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfer_items
    ADD CONSTRAINT inventory_transfer_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4142 (class 2606 OID 17960)
-- Name: inventory_transfers inventory_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfers
    ADD CONSTRAINT inventory_transfers_pkey PRIMARY KEY (id);


--
-- TOC entry 4113 (class 2606 OID 17923)
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- TOC entry 4193 (class 2606 OID 18030)
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_pkey PRIMARY KEY (id);


--
-- TOC entry 4220 (class 2606 OID 18054)
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4211 (class 2606 OID 18044)
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- TOC entry 4226 (class 2606 OID 18063)
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- TOC entry 4103 (class 2606 OID 17904)
-- Name: product_attributes product_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_attributes
    ADD CONSTRAINT product_attributes_pkey PRIMARY KEY (id);


--
-- TOC entry 4099 (class 2606 OID 17897)
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- TOC entry 4092 (class 2606 OID 17888)
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- TOC entry 4078 (class 2606 OID 17879)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- TOC entry 4244 (class 2606 OID 18097)
-- Name: return_items return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4238 (class 2606 OID 18089)
-- Name: returns returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_pkey PRIMARY KEY (id);


--
-- TOC entry 4035 (class 2606 OID 17831)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4250 (class 2606 OID 18112)
-- Name: shopify_syncs shopify_syncs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopify_syncs
    ADD CONSTRAINT shopify_syncs_pkey PRIMARY KEY (id);


--
-- TOC entry 4256 (class 2606 OID 18122)
-- Name: shopify_webhooks shopify_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopify_webhooks
    ADD CONSTRAINT shopify_webhooks_pkey PRIMARY KEY (id);


--
-- TOC entry 4272 (class 2606 OID 18138)
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- TOC entry 4037 (class 2606 OID 17839)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4042 (class 2606 OID 17847)
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4030 (class 2606 OID 17823)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4260 (class 1259 OID 18254)
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- TOC entry 4261 (class 1259 OID 18252)
-- Name: audit_logs_entity_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_entity_entityId_idx" ON public.audit_logs USING btree (entity, "entityId");


--
-- TOC entry 4264 (class 1259 OID 18253)
-- Name: audit_logs_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_userId_idx" ON public.audit_logs USING btree ("userId");


--
-- TOC entry 4048 (class 1259 OID 18155)
-- Name: categories_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "categories_isActive_idx" ON public.categories USING btree ("isActive");


--
-- TOC entry 4049 (class 1259 OID 18154)
-- Name: categories_parentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "categories_parentId_idx" ON public.categories USING btree ("parentId");


--
-- TOC entry 4052 (class 1259 OID 18153)
-- Name: categories_slug_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX categories_slug_idx ON public.categories USING btree (slug);


--
-- TOC entry 4053 (class 1259 OID 18152)
-- Name: categories_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX categories_slug_key ON public.categories USING btree (slug);


--
-- TOC entry 4105 (class 1259 OID 18182)
-- Name: collection_products_collectionId_productId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "collection_products_collectionId_productId_key" ON public.collection_products USING btree ("collectionId", "productId");


--
-- TOC entry 4056 (class 1259 OID 18158)
-- Name: collections_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "collections_isActive_idx" ON public.collections USING btree ("isActive");


--
-- TOC entry 4059 (class 1259 OID 18157)
-- Name: collections_slug_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX collections_slug_idx ON public.collections USING btree (slug);


--
-- TOC entry 4060 (class 1259 OID 18156)
-- Name: collections_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX collections_slug_key ON public.collections USING btree (slug);


--
-- TOC entry 4168 (class 1259 OID 18210)
-- Name: customer_addresses_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customer_addresses_customerId_idx" ON public.customer_addresses USING btree ("customerId");


--
-- TOC entry 4171 (class 1259 OID 18211)
-- Name: customer_addresses_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_addresses_type_idx ON public.customer_addresses USING btree (type);


--
-- TOC entry 4181 (class 1259 OID 18217)
-- Name: customer_interactions_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customer_interactions_createdAt_idx" ON public.customer_interactions USING btree ("createdAt");


--
-- TOC entry 4182 (class 1259 OID 18215)
-- Name: customer_interactions_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customer_interactions_customerId_idx" ON public.customer_interactions USING btree ("customerId");


--
-- TOC entry 4185 (class 1259 OID 18216)
-- Name: customer_interactions_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_interactions_type_idx ON public.customer_interactions USING btree (type);


--
-- TOC entry 4178 (class 1259 OID 18214)
-- Name: customer_segment_members_customerId_segmentId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "customer_segment_members_customerId_segmentId_key" ON public.customer_segment_members USING btree ("customerId", "segmentId");


--
-- TOC entry 4174 (class 1259 OID 18213)
-- Name: customer_segments_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customer_segments_isActive_idx" ON public.customer_segments USING btree ("isActive");


--
-- TOC entry 4175 (class 1259 OID 18212)
-- Name: customer_segments_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX customer_segments_name_key ON public.customer_segments USING btree (name);


--
-- TOC entry 4148 (class 1259 OID 18207)
-- Name: customers_customerSince_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customers_customerSince_idx" ON public.customers USING btree ("customerSince");


--
-- TOC entry 4149 (class 1259 OID 18209)
-- Name: customers_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customers_deletedAt_idx" ON public.customers USING btree ("deletedAt");


--
-- TOC entry 4150 (class 1259 OID 18204)
-- Name: customers_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_email_idx ON public.customers USING btree (email);


--
-- TOC entry 4151 (class 1259 OID 18202)
-- Name: customers_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX customers_email_key ON public.customers USING btree (email);


--
-- TOC entry 4152 (class 1259 OID 18205)
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- TOC entry 4155 (class 1259 OID 18208)
-- Name: customers_shopifyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customers_shopifyId_idx" ON public.customers USING btree ("shopifyId");


--
-- TOC entry 4156 (class 1259 OID 18203)
-- Name: customers_shopifyId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "customers_shopifyId_key" ON public.customers USING btree ("shopifyId");


--
-- TOC entry 4157 (class 1259 OID 18206)
-- Name: customers_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_status_idx ON public.customers USING btree (status);


--
-- TOC entry 4232 (class 1259 OID 18238)
-- Name: fulfillment_items_fulfillmentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fulfillment_items_fulfillmentId_idx" ON public.fulfillment_items USING btree ("fulfillmentId");


--
-- TOC entry 4233 (class 1259 OID 18239)
-- Name: fulfillment_items_orderItemId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fulfillment_items_orderItemId_idx" ON public.fulfillment_items USING btree ("orderItemId");


--
-- TOC entry 4228 (class 1259 OID 18236)
-- Name: fulfillments_orderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fulfillments_orderId_idx" ON public.fulfillments USING btree ("orderId");


--
-- TOC entry 4231 (class 1259 OID 18237)
-- Name: fulfillments_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fulfillments_status_idx ON public.fulfillments USING btree (status);


--
-- TOC entry 4265 (class 1259 OID 18484)
-- Name: idx_audit_logs_action_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_action_date ON public.audit_logs USING btree (action, "createdAt" DESC);


--
-- TOC entry 4266 (class 1259 OID 18482)
-- Name: idx_audit_logs_entity_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_entity_date ON public.audit_logs USING btree (entity, "entityId", "createdAt" DESC);


--
-- TOC entry 4267 (class 1259 OID 18483)
-- Name: idx_audit_logs_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_user_date ON public.audit_logs USING btree ("userId", "createdAt" DESC) WHERE ("userId" IS NOT NULL);


--
-- TOC entry 4054 (class 1259 OID 18490)
-- Name: idx_categories_active_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_categories_active_sort ON public.categories USING btree ("isActive", "sortOrder") WHERE ("isActive" = true);


--
-- TOC entry 4055 (class 1259 OID 18489)
-- Name: idx_categories_parent_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_categories_parent_sort ON public.categories USING btree ("parentId", "sortOrder") WHERE ("parentId" IS NOT NULL);


--
-- TOC entry 4108 (class 1259 OID 18488)
-- Name: idx_collection_products_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_collection_products_sort ON public.collection_products USING btree ("collectionId", "sortOrder");


--
-- TOC entry 4172 (class 1259 OID 18470)
-- Name: idx_customer_addresses_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_addresses_location ON public.customer_addresses USING btree (country, state, city);


--
-- TOC entry 4173 (class 1259 OID 18471)
-- Name: idx_customer_addresses_postal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_addresses_postal ON public.customer_addresses USING btree ("postalCode");


--
-- TOC entry 4186 (class 1259 OID 18492)
-- Name: idx_customer_interactions_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_interactions_channel ON public.customer_interactions USING btree (channel, "createdAt" DESC);


--
-- TOC entry 4187 (class 1259 OID 18491)
-- Name: idx_customer_interactions_type_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_interactions_type_date ON public.customer_interactions USING btree (type, "createdAt" DESC);


--
-- TOC entry 4158 (class 1259 OID 18469)
-- Name: idx_customers_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_created_at ON public.customers USING btree ("customerSince" DESC);


--
-- TOC entry 4159 (class 1259 OID 18464)
-- Name: idx_customers_email_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_email_domain ON public.customers USING btree (split_part(email, '@'::text, 2)) WHERE (email IS NOT NULL);


--
-- TOC entry 4160 (class 1259 OID 18505)
-- Name: idx_customers_full_text; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_full_text ON public.customers USING gin (to_tsvector('english'::regconfig, ((((COALESCE("firstName", ''::text) || ' '::text) || COALESCE("lastName", ''::text)) || ' '::text) || COALESCE(email, ''::text)))) WHERE (("firstName" IS NOT NULL) OR ("lastName" IS NOT NULL) OR (email IS NOT NULL));


--
-- TOC entry 4161 (class 1259 OID 18467)
-- Name: idx_customers_last_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_last_order ON public.customers USING btree ("lastOrderAt" DESC NULLS LAST);


--
-- TOC entry 4162 (class 1259 OID 18465)
-- Name: idx_customers_lifetime_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_lifetime_value ON public.customers USING btree ("lifetimeValue" DESC);


--
-- TOC entry 4163 (class 1259 OID 18468)
-- Name: idx_customers_loyalty_points; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_loyalty_points ON public.customers USING btree ("loyaltyPoints" DESC);


--
-- TOC entry 4164 (class 1259 OID 18463)
-- Name: idx_customers_name_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_name_search ON public.customers USING gin (to_tsvector('english'::regconfig, (("firstName" || ' '::text) || "lastName")));


--
-- TOC entry 4165 (class 1259 OID 18498)
-- Name: idx_customers_status_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_status_value ON public.customers USING btree (status, "lifetimeValue" DESC) WHERE (status = 'ACTIVE'::public."CustomerStatus");


--
-- TOC entry 4166 (class 1259 OID 18466)
-- Name: idx_customers_total_orders; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_total_orders ON public.customers USING btree ("totalOrders" DESC);


--
-- TOC entry 4167 (class 1259 OID 18503)
-- Name: idx_customers_vip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_vip ON public.customers USING btree ("lifetimeValue" DESC) WHERE ("lifetimeValue" > (500)::numeric);


--
-- TOC entry 4127 (class 1259 OID 18475)
-- Name: idx_inventory_adjustments_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_adjustments_date ON public.inventory_adjustments USING btree ("createdAt" DESC);


--
-- TOC entry 4128 (class 1259 OID 18477)
-- Name: idx_inventory_adjustments_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_adjustments_reference ON public.inventory_adjustments USING btree ("referenceType", "referenceId") WHERE ("referenceType" IS NOT NULL);


--
-- TOC entry 4129 (class 1259 OID 18476)
-- Name: idx_inventory_adjustments_type_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_adjustments_type_date ON public.inventory_adjustments USING btree (type, "createdAt" DESC);


--
-- TOC entry 4115 (class 1259 OID 18454)
-- Name: idx_inventory_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_available ON public.inventory_items USING btree ("availableQuantity") WHERE ("availableQuantity" > 0);


--
-- TOC entry 4116 (class 1259 OID 18496)
-- Name: idx_inventory_location_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_location_available ON public.inventory_items USING btree ("locationId", "availableQuantity") WHERE ("availableQuantity" > 0);


--
-- TOC entry 4117 (class 1259 OID 18455)
-- Name: idx_inventory_location_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_location_product ON public.inventory_items USING btree ("locationId", "productId");


--
-- TOC entry 4118 (class 1259 OID 18453)
-- Name: idx_inventory_low_stock; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_low_stock ON public.inventory_items USING btree (quantity, "lowStockThreshold") WHERE (quantity <= "lowStockThreshold");


--
-- TOC entry 4119 (class 1259 OID 18456)
-- Name: idx_inventory_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_updated_at ON public.inventory_items USING btree ("updatedAt" DESC);


--
-- TOC entry 4188 (class 1259 OID 18494)
-- Name: idx_loyalty_transactions_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loyalty_transactions_reference ON public.loyalty_transactions USING btree ("referenceType", "referenceId") WHERE ("referenceType" IS NOT NULL);


--
-- TOC entry 4189 (class 1259 OID 18493)
-- Name: idx_loyalty_transactions_type_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loyalty_transactions_type_date ON public.loyalty_transactions USING btree (type, "createdAt" DESC);


--
-- TOC entry 4215 (class 1259 OID 18472)
-- Name: idx_order_items_product_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_product_date ON public.order_items USING btree ("productId", "createdAt" DESC);


--
-- TOC entry 4216 (class 1259 OID 18474)
-- Name: idx_order_items_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_sku ON public.order_items USING btree (sku) WHERE (sku IS NOT NULL);


--
-- TOC entry 4217 (class 1259 OID 18473)
-- Name: idx_order_items_variant_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_variant_date ON public.order_items USING btree ("variantId", "createdAt" DESC);


--
-- TOC entry 4195 (class 1259 OID 18457)
-- Name: idx_orders_customer_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_customer_date ON public.orders USING btree ("customerId", "orderDate" DESC);


--
-- TOC entry 4196 (class 1259 OID 18497)
-- Name: idx_orders_customer_status_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_customer_status_date ON public.orders USING btree ("customerId", status, "orderDate" DESC);


--
-- TOC entry 4197 (class 1259 OID 18462)
-- Name: idx_orders_date_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_date_range ON public.orders USING btree ("orderDate" DESC, status);


--
-- TOC entry 4198 (class 1259 OID 18459)
-- Name: idx_orders_financial_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_financial_status ON public.orders USING btree ("financialStatus", "orderDate" DESC);


--
-- TOC entry 4199 (class 1259 OID 18460)
-- Name: idx_orders_fulfillment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_fulfillment_status ON public.orders USING btree ("fulfillmentStatus", "orderDate" DESC);


--
-- TOC entry 4200 (class 1259 OID 18501)
-- Name: idx_orders_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_pending ON public.orders USING btree ("createdAt" DESC) WHERE (status = 'PENDING'::public."OrderStatus");


--
-- TOC entry 4201 (class 1259 OID 18502)
-- Name: idx_orders_processing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_processing ON public.orders USING btree ("createdAt" DESC) WHERE (status = 'PROCESSING'::public."OrderStatus");


--
-- TOC entry 4202 (class 1259 OID 18458)
-- Name: idx_orders_status_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_status_date ON public.orders USING btree (status, "orderDate" DESC);


--
-- TOC entry 4203 (class 1259 OID 18461)
-- Name: idx_orders_total_amount; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_total_amount ON public.orders USING btree ("totalAmount" DESC);


--
-- TOC entry 4086 (class 1259 OID 18451)
-- Name: idx_product_variants_options; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_variants_options ON public.product_variants USING btree ("option1Value", "option2Value", "option3Value");


--
-- TOC entry 4087 (class 1259 OID 18452)
-- Name: idx_product_variants_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_variants_price ON public.product_variants USING btree (price);


--
-- TOC entry 4061 (class 1259 OID 18500)
-- Name: idx_products_active_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_active_price ON public.products USING btree (price, "createdAt" DESC) WHERE (("isActive" = true) AND (status = 'ACTIVE'::public."ProductStatus"));


--
-- TOC entry 4062 (class 1259 OID 18446)
-- Name: idx_products_brand; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_brand ON public.products USING btree (brand);


--
-- TOC entry 4063 (class 1259 OID 18495)
-- Name: idx_products_category_status_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_category_status_active ON public.products USING btree ("categoryId", status, "isActive") WHERE ("isActive" = true);


--
-- TOC entry 4064 (class 1259 OID 18449)
-- Name: idx_products_created_at_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_created_at_desc ON public.products USING btree ("createdAt" DESC);


--
-- TOC entry 4065 (class 1259 OID 18445)
-- Name: idx_products_description_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_description_search ON public.products USING gin (to_tsvector('english'::regconfig, description));


--
-- TOC entry 4066 (class 1259 OID 18499)
-- Name: idx_products_featured; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_featured ON public.products USING btree ("isFeatured", "createdAt" DESC) WHERE ("isFeatured" = true);


--
-- TOC entry 4067 (class 1259 OID 18504)
-- Name: idx_products_full_text; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_full_text ON public.products USING gin (to_tsvector('english'::regconfig, ((((((COALESCE(name, ''::text) || ' '::text) || COALESCE(description, ''::text)) || ' '::text) || COALESCE(brand, ''::text)) || ' '::text) || COALESCE(material, ''::text))));


--
-- TOC entry 4068 (class 1259 OID 18447)
-- Name: idx_products_material; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_material ON public.products USING btree (material);


--
-- TOC entry 4069 (class 1259 OID 18444)
-- Name: idx_products_name_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_name_search ON public.products USING gin (to_tsvector('english'::regconfig, name));


--
-- TOC entry 4070 (class 1259 OID 18448)
-- Name: idx_products_price_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_price_range ON public.products USING btree (price, "compareAtPrice");


--
-- TOC entry 4071 (class 1259 OID 18450)
-- Name: idx_products_updated_at_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_updated_at_desc ON public.products USING btree ("updatedAt" DESC);


--
-- TOC entry 4246 (class 1259 OID 18478)
-- Name: idx_shopify_syncs_status_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shopify_syncs_status_date ON public.shopify_syncs USING btree (status, "createdAt" DESC);


--
-- TOC entry 4247 (class 1259 OID 18479)
-- Name: idx_shopify_syncs_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shopify_syncs_type_status ON public.shopify_syncs USING btree (type, status);


--
-- TOC entry 4253 (class 1259 OID 18480)
-- Name: idx_shopify_webhooks_processed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shopify_webhooks_processed ON public.shopify_webhooks USING btree (processed, "receivedAt" DESC);


--
-- TOC entry 4254 (class 1259 OID 18481)
-- Name: idx_shopify_webhooks_topic; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shopify_webhooks_topic ON public.shopify_webhooks USING btree (topic, "receivedAt" DESC);


--
-- TOC entry 4268 (class 1259 OID 18485)
-- Name: idx_system_health_service_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_health_service_date ON public.system_health USING btree (service, "checkedAt" DESC);


--
-- TOC entry 4269 (class 1259 OID 18486)
-- Name: idx_system_health_status_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_health_status_date ON public.system_health USING btree (status, "checkedAt" DESC);


--
-- TOC entry 4039 (class 1259 OID 18487)
-- Name: idx_user_sessions_last_used; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_last_used ON public.user_sessions USING btree ("lastUsedAt" DESC NULLS LAST);


--
-- TOC entry 4130 (class 1259 OID 18194)
-- Name: inventory_adjustments_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_adjustments_createdAt_idx" ON public.inventory_adjustments USING btree ("createdAt");


--
-- TOC entry 4131 (class 1259 OID 18192)
-- Name: inventory_adjustments_inventoryItemId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_adjustments_inventoryItemId_idx" ON public.inventory_adjustments USING btree ("inventoryItemId");


--
-- TOC entry 4134 (class 1259 OID 18193)
-- Name: inventory_adjustments_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_adjustments_type_idx ON public.inventory_adjustments USING btree (type);


--
-- TOC entry 4120 (class 1259 OID 18189)
-- Name: inventory_items_availableQuantity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_items_availableQuantity_idx" ON public.inventory_items USING btree ("availableQuantity");


--
-- TOC entry 4121 (class 1259 OID 18187)
-- Name: inventory_items_locationId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_items_locationId_idx" ON public.inventory_items USING btree ("locationId");


--
-- TOC entry 4122 (class 1259 OID 18190)
-- Name: inventory_items_lowStockThreshold_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_items_lowStockThreshold_idx" ON public.inventory_items USING btree ("lowStockThreshold");


--
-- TOC entry 4125 (class 1259 OID 18191)
-- Name: inventory_items_productId_variantId_locationId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "inventory_items_productId_variantId_locationId_key" ON public.inventory_items USING btree ("productId", "variantId", "locationId");


--
-- TOC entry 4126 (class 1259 OID 18188)
-- Name: inventory_items_quantity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_items_quantity_idx ON public.inventory_items USING btree (quantity);


--
-- TOC entry 4135 (class 1259 OID 18196)
-- Name: inventory_reservations_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_reservations_expiresAt_idx" ON public.inventory_reservations USING btree ("expiresAt");


--
-- TOC entry 4136 (class 1259 OID 18195)
-- Name: inventory_reservations_inventoryItemId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_reservations_inventoryItemId_idx" ON public.inventory_reservations USING btree ("inventoryItemId");


--
-- TOC entry 4147 (class 1259 OID 18201)
-- Name: inventory_transfer_items_transferId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_transfer_items_transferId_idx" ON public.inventory_transfer_items USING btree ("transferId");


--
-- TOC entry 4139 (class 1259 OID 18200)
-- Name: inventory_transfers_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_transfers_createdAt_idx" ON public.inventory_transfers USING btree ("createdAt");


--
-- TOC entry 4140 (class 1259 OID 18197)
-- Name: inventory_transfers_fromLocationId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_transfers_fromLocationId_idx" ON public.inventory_transfers USING btree ("fromLocationId");


--
-- TOC entry 4143 (class 1259 OID 18199)
-- Name: inventory_transfers_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_transfers_status_idx ON public.inventory_transfers USING btree (status);


--
-- TOC entry 4144 (class 1259 OID 18198)
-- Name: inventory_transfers_toLocationId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inventory_transfers_toLocationId_idx" ON public.inventory_transfers USING btree ("toLocationId");


--
-- TOC entry 4109 (class 1259 OID 18184)
-- Name: locations_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX locations_code_idx ON public.locations USING btree (code);


--
-- TOC entry 4110 (class 1259 OID 18183)
-- Name: locations_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX locations_code_key ON public.locations USING btree (code);


--
-- TOC entry 4111 (class 1259 OID 18186)
-- Name: locations_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "locations_isActive_idx" ON public.locations USING btree ("isActive");


--
-- TOC entry 4114 (class 1259 OID 18185)
-- Name: locations_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX locations_type_idx ON public.locations USING btree (type);


--
-- TOC entry 4190 (class 1259 OID 18220)
-- Name: loyalty_transactions_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "loyalty_transactions_createdAt_idx" ON public.loyalty_transactions USING btree ("createdAt");


--
-- TOC entry 4191 (class 1259 OID 18218)
-- Name: loyalty_transactions_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "loyalty_transactions_customerId_idx" ON public.loyalty_transactions USING btree ("customerId");


--
-- TOC entry 4194 (class 1259 OID 18219)
-- Name: loyalty_transactions_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loyalty_transactions_type_idx ON public.loyalty_transactions USING btree (type);


--
-- TOC entry 4218 (class 1259 OID 18230)
-- Name: order_items_orderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "order_items_orderId_idx" ON public.order_items USING btree ("orderId");


--
-- TOC entry 4221 (class 1259 OID 18231)
-- Name: order_items_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "order_items_productId_idx" ON public.order_items USING btree ("productId");


--
-- TOC entry 4222 (class 1259 OID 18232)
-- Name: order_items_variantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "order_items_variantId_idx" ON public.order_items USING btree ("variantId");


--
-- TOC entry 4204 (class 1259 OID 18224)
-- Name: orders_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_customerId_idx" ON public.orders USING btree ("customerId");


--
-- TOC entry 4205 (class 1259 OID 18226)
-- Name: orders_financialStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_financialStatus_idx" ON public.orders USING btree ("financialStatus");


--
-- TOC entry 4206 (class 1259 OID 18227)
-- Name: orders_fulfillmentStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_fulfillmentStatus_idx" ON public.orders USING btree ("fulfillmentStatus");


--
-- TOC entry 4207 (class 1259 OID 18228)
-- Name: orders_orderDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_orderDate_idx" ON public.orders USING btree ("orderDate");


--
-- TOC entry 4208 (class 1259 OID 18223)
-- Name: orders_orderNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_orderNumber_idx" ON public.orders USING btree ("orderNumber");


--
-- TOC entry 4209 (class 1259 OID 18221)
-- Name: orders_orderNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "orders_orderNumber_key" ON public.orders USING btree ("orderNumber");


--
-- TOC entry 4212 (class 1259 OID 18229)
-- Name: orders_shopifyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_shopifyId_idx" ON public.orders USING btree ("shopifyId");


--
-- TOC entry 4213 (class 1259 OID 18222)
-- Name: orders_shopifyId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "orders_shopifyId_key" ON public.orders USING btree ("shopifyId");


--
-- TOC entry 4214 (class 1259 OID 18225)
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- TOC entry 4223 (class 1259 OID 18235)
-- Name: payments_method_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_method_idx ON public.payments USING btree (method);


--
-- TOC entry 4224 (class 1259 OID 18233)
-- Name: payments_orderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "payments_orderId_idx" ON public.payments USING btree ("orderId");


--
-- TOC entry 4227 (class 1259 OID 18234)
-- Name: payments_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_status_idx ON public.payments USING btree (status);


--
-- TOC entry 4104 (class 1259 OID 18181)
-- Name: product_attributes_productId_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "product_attributes_productId_name_key" ON public.product_attributes USING btree ("productId", name);


--
-- TOC entry 4100 (class 1259 OID 18179)
-- Name: product_images_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "product_images_productId_idx" ON public.product_images USING btree ("productId");


--
-- TOC entry 4101 (class 1259 OID 18180)
-- Name: product_images_sortOrder_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "product_images_sortOrder_idx" ON public.product_images USING btree ("sortOrder");


--
-- TOC entry 4088 (class 1259 OID 18176)
-- Name: product_variants_barcode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_variants_barcode_idx ON public.product_variants USING btree (barcode);


--
-- TOC entry 4089 (class 1259 OID 18172)
-- Name: product_variants_barcode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_variants_barcode_key ON public.product_variants USING btree (barcode);


--
-- TOC entry 4090 (class 1259 OID 18177)
-- Name: product_variants_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "product_variants_isActive_idx" ON public.product_variants USING btree ("isActive");


--
-- TOC entry 4093 (class 1259 OID 18174)
-- Name: product_variants_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "product_variants_productId_idx" ON public.product_variants USING btree ("productId");


--
-- TOC entry 4094 (class 1259 OID 18178)
-- Name: product_variants_shopifyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "product_variants_shopifyId_idx" ON public.product_variants USING btree ("shopifyId");


--
-- TOC entry 4095 (class 1259 OID 18173)
-- Name: product_variants_shopifyId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "product_variants_shopifyId_key" ON public.product_variants USING btree ("shopifyId");


--
-- TOC entry 4096 (class 1259 OID 18175)
-- Name: product_variants_sku_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_variants_sku_idx ON public.product_variants USING btree (sku);


--
-- TOC entry 4097 (class 1259 OID 18171)
-- Name: product_variants_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_variants_sku_key ON public.product_variants USING btree (sku);


--
-- TOC entry 4072 (class 1259 OID 18165)
-- Name: products_barcode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_barcode_idx ON public.products USING btree (barcode);


--
-- TOC entry 4073 (class 1259 OID 18161)
-- Name: products_barcode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_barcode_key ON public.products USING btree (barcode);


--
-- TOC entry 4074 (class 1259 OID 18168)
-- Name: products_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "products_categoryId_idx" ON public.products USING btree ("categoryId");


--
-- TOC entry 4075 (class 1259 OID 18170)
-- Name: products_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "products_deletedAt_idx" ON public.products USING btree ("deletedAt");


--
-- TOC entry 4076 (class 1259 OID 18167)
-- Name: products_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "products_isActive_idx" ON public.products USING btree ("isActive");


--
-- TOC entry 4079 (class 1259 OID 18169)
-- Name: products_shopifyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "products_shopifyId_idx" ON public.products USING btree ("shopifyId");


--
-- TOC entry 4080 (class 1259 OID 18162)
-- Name: products_shopifyId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "products_shopifyId_key" ON public.products USING btree ("shopifyId");


--
-- TOC entry 4081 (class 1259 OID 18164)
-- Name: products_sku_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_sku_idx ON public.products USING btree (sku);


--
-- TOC entry 4082 (class 1259 OID 18160)
-- Name: products_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_sku_key ON public.products USING btree (sku);


--
-- TOC entry 4083 (class 1259 OID 18163)
-- Name: products_slug_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_slug_idx ON public.products USING btree (slug);


--
-- TOC entry 4084 (class 1259 OID 18159)
-- Name: products_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_slug_key ON public.products USING btree (slug);


--
-- TOC entry 4085 (class 1259 OID 18166)
-- Name: products_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_status_idx ON public.products USING btree (status);


--
-- TOC entry 4242 (class 1259 OID 18245)
-- Name: return_items_orderItemId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "return_items_orderItemId_idx" ON public.return_items USING btree ("orderItemId");


--
-- TOC entry 4245 (class 1259 OID 18244)
-- Name: return_items_returnId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "return_items_returnId_idx" ON public.return_items USING btree ("returnId");


--
-- TOC entry 4236 (class 1259 OID 18241)
-- Name: returns_orderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "returns_orderId_idx" ON public.returns USING btree ("orderId");


--
-- TOC entry 4239 (class 1259 OID 18242)
-- Name: returns_returnNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "returns_returnNumber_idx" ON public.returns USING btree ("returnNumber");


--
-- TOC entry 4240 (class 1259 OID 18240)
-- Name: returns_returnNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "returns_returnNumber_key" ON public.returns USING btree ("returnNumber");


--
-- TOC entry 4241 (class 1259 OID 18243)
-- Name: returns_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX returns_status_idx ON public.returns USING btree (status);


--
-- TOC entry 4033 (class 1259 OID 18144)
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- TOC entry 4248 (class 1259 OID 18248)
-- Name: shopify_syncs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "shopify_syncs_createdAt_idx" ON public.shopify_syncs USING btree ("createdAt");


--
-- TOC entry 4251 (class 1259 OID 18247)
-- Name: shopify_syncs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shopify_syncs_status_idx ON public.shopify_syncs USING btree (status);


--
-- TOC entry 4252 (class 1259 OID 18246)
-- Name: shopify_syncs_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shopify_syncs_type_idx ON public.shopify_syncs USING btree (type);


--
-- TOC entry 4257 (class 1259 OID 18250)
-- Name: shopify_webhooks_processed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shopify_webhooks_processed_idx ON public.shopify_webhooks USING btree (processed);


--
-- TOC entry 4258 (class 1259 OID 18251)
-- Name: shopify_webhooks_receivedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "shopify_webhooks_receivedAt_idx" ON public.shopify_webhooks USING btree ("receivedAt");


--
-- TOC entry 4259 (class 1259 OID 18249)
-- Name: shopify_webhooks_topic_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shopify_webhooks_topic_idx ON public.shopify_webhooks USING btree (topic);


--
-- TOC entry 4270 (class 1259 OID 18257)
-- Name: system_health_checkedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "system_health_checkedAt_idx" ON public.system_health USING btree ("checkedAt");


--
-- TOC entry 4273 (class 1259 OID 18255)
-- Name: system_health_service_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_service_idx ON public.system_health USING btree (service);


--
-- TOC entry 4274 (class 1259 OID 18256)
-- Name: system_health_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_status_idx ON public.system_health USING btree (status);


--
-- TOC entry 4038 (class 1259 OID 18145)
-- Name: user_roles_userId_roleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_roles_userId_roleId_key" ON public.user_roles USING btree ("userId", "roleId");


--
-- TOC entry 4040 (class 1259 OID 18151)
-- Name: user_sessions_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "user_sessions_expiresAt_idx" ON public.user_sessions USING btree ("expiresAt");


--
-- TOC entry 4043 (class 1259 OID 18149)
-- Name: user_sessions_refreshToken_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "user_sessions_refreshToken_idx" ON public.user_sessions USING btree ("refreshToken");


--
-- TOC entry 4044 (class 1259 OID 18147)
-- Name: user_sessions_refreshToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_sessions_refreshToken_key" ON public.user_sessions USING btree ("refreshToken");


--
-- TOC entry 4045 (class 1259 OID 18148)
-- Name: user_sessions_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_token_idx ON public.user_sessions USING btree (token);


--
-- TOC entry 4046 (class 1259 OID 18146)
-- Name: user_sessions_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_sessions_token_key ON public.user_sessions USING btree (token);


--
-- TOC entry 4047 (class 1259 OID 18150)
-- Name: user_sessions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "user_sessions_userId_idx" ON public.user_sessions USING btree ("userId");


--
-- TOC entry 4026 (class 1259 OID 18143)
-- Name: users_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "users_deletedAt_idx" ON public.users USING btree ("deletedAt");


--
-- TOC entry 4027 (class 1259 OID 18141)
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- TOC entry 4028 (class 1259 OID 18139)
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- TOC entry 4031 (class 1259 OID 18142)
-- Name: users_username_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_username_idx ON public.users USING btree (username);


--
-- TOC entry 4032 (class 1259 OID 18140)
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- TOC entry 4311 (class 2606 OID 18438)
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4278 (class 2606 OID 18273)
-- Name: categories categories_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4283 (class 2606 OID 18298)
-- Name: collection_products collection_products_collectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_products
    ADD CONSTRAINT "collection_products_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES public.collections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4284 (class 2606 OID 18303)
-- Name: collection_products collection_products_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_products
    ADD CONSTRAINT "collection_products_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4293 (class 2606 OID 18348)
-- Name: customer_addresses customer_addresses_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_addresses
    ADD CONSTRAINT "customer_addresses_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4296 (class 2606 OID 18363)
-- Name: customer_interactions customer_interactions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_interactions
    ADD CONSTRAINT "customer_interactions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4294 (class 2606 OID 18353)
-- Name: customer_segment_members customer_segment_members_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_segment_members
    ADD CONSTRAINT "customer_segment_members_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4295 (class 2606 OID 18358)
-- Name: customer_segment_members customer_segment_members_segmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_segment_members
    ADD CONSTRAINT "customer_segment_members_segmentId_fkey" FOREIGN KEY ("segmentId") REFERENCES public.customer_segments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4306 (class 2606 OID 18413)
-- Name: fulfillment_items fulfillment_items_fulfillmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_items
    ADD CONSTRAINT "fulfillment_items_fulfillmentId_fkey" FOREIGN KEY ("fulfillmentId") REFERENCES public.fulfillments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4307 (class 2606 OID 18418)
-- Name: fulfillment_items fulfillment_items_orderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_items
    ADD CONSTRAINT "fulfillment_items_orderItemId_fkey" FOREIGN KEY ("orderItemId") REFERENCES public.order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4305 (class 2606 OID 18408)
-- Name: fulfillments fulfillments_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillments
    ADD CONSTRAINT "fulfillments_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4288 (class 2606 OID 18323)
-- Name: inventory_adjustments inventory_adjustments_inventoryItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT "inventory_adjustments_inventoryItemId_fkey" FOREIGN KEY ("inventoryItemId") REFERENCES public.inventory_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4285 (class 2606 OID 18318)
-- Name: inventory_items inventory_items_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT "inventory_items_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public.locations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4286 (class 2606 OID 18308)
-- Name: inventory_items inventory_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT "inventory_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4287 (class 2606 OID 18313)
-- Name: inventory_items inventory_items_variantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT "inventory_items_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4289 (class 2606 OID 18328)
-- Name: inventory_reservations inventory_reservations_inventoryItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT "inventory_reservations_inventoryItemId_fkey" FOREIGN KEY ("inventoryItemId") REFERENCES public.inventory_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4292 (class 2606 OID 18343)
-- Name: inventory_transfer_items inventory_transfer_items_transferId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfer_items
    ADD CONSTRAINT "inventory_transfer_items_transferId_fkey" FOREIGN KEY ("transferId") REFERENCES public.inventory_transfers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4290 (class 2606 OID 18333)
-- Name: inventory_transfers inventory_transfers_fromLocationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfers
    ADD CONSTRAINT "inventory_transfers_fromLocationId_fkey" FOREIGN KEY ("fromLocationId") REFERENCES public.locations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4291 (class 2606 OID 18338)
-- Name: inventory_transfers inventory_transfers_toLocationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfers
    ADD CONSTRAINT "inventory_transfers_toLocationId_fkey" FOREIGN KEY ("toLocationId") REFERENCES public.locations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4297 (class 2606 OID 18368)
-- Name: loyalty_transactions loyalty_transactions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT "loyalty_transactions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4301 (class 2606 OID 18388)
-- Name: order_items order_items_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4302 (class 2606 OID 18393)
-- Name: order_items order_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4303 (class 2606 OID 18398)
-- Name: order_items order_items_variantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4298 (class 2606 OID 18378)
-- Name: orders orders_billingAddressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_billingAddressId_fkey" FOREIGN KEY ("billingAddressId") REFERENCES public.customer_addresses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4299 (class 2606 OID 18373)
-- Name: orders orders_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4300 (class 2606 OID 18383)
-- Name: orders orders_shippingAddressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_shippingAddressId_fkey" FOREIGN KEY ("shippingAddressId") REFERENCES public.customer_addresses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4304 (class 2606 OID 18403)
-- Name: payments payments_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4282 (class 2606 OID 18293)
-- Name: product_attributes product_attributes_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_attributes
    ADD CONSTRAINT "product_attributes_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4281 (class 2606 OID 18288)
-- Name: product_images product_images_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT "product_images_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4280 (class 2606 OID 18283)
-- Name: product_variants product_variants_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT "product_variants_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4279 (class 2606 OID 18278)
-- Name: products products_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4309 (class 2606 OID 18433)
-- Name: return_items return_items_orderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT "return_items_orderItemId_fkey" FOREIGN KEY ("orderItemId") REFERENCES public.order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4310 (class 2606 OID 18428)
-- Name: return_items return_items_returnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT "return_items_returnId_fkey" FOREIGN KEY ("returnId") REFERENCES public.returns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4308 (class 2606 OID 18423)
-- Name: returns returns_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT "returns_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4275 (class 2606 OID 18263)
-- Name: user_roles user_roles_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4276 (class 2606 OID 18258)
-- Name: user_roles user_roles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4277 (class 2606 OID 18268)
-- Name: user_sessions user_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT "user_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2025-08-14 16:40:07 UTC

--
-- PostgreSQL database dump complete
--

